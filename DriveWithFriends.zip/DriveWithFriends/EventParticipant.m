//
//  GroupMember.m
//  TelenavNavigator
//
//  Created by gyhuang on 13-7-3.
//  Copyright (c) 2013年 Telenav, Inc. All rights reserved.
//

#import "EventParticipant.h"

@implementation EventParticipant
@synthesize name;
@synthesize id;
@synthesize joinDate;

@end
